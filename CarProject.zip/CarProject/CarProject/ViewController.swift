//
//  ViewController.swift
//  CarProject
//
//  Created by user202391 on 2/7/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
            configureTextFields()
    }
    private func configureTextFields(){
        carTextField.delegate = self
    }

    @IBOutlet weak var carImage: UIImageView!
    @IBOutlet weak var carTextField: UITextField!
    
    
    
    
    
    @IBAction func changeImageBtn(_ sender: Any) {
        if(carTextField.text=="Car 1"){
            carImage.image=UIImage(named:"car1")
        }
        else if(carTextField.text=="Car 2"){
            carImage.image=UIImage(named:"car2")
        }
        else if(carTextField.text=="Car 3"){
            carImage.image=UIImage(named:"car3")
        }
        else if(carTextField.text=="Car 4"){
            carImage.image=UIImage(named:"car4")
        }
        else{
            carImage.image=UIImage(named:"car1")
        }
    }
}
extension ViewController:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}


