//
//  ViewController.swift
//  Lab5
//
//  Created by user202391 on 3/20/22.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController,CLLocationManagerDelegate, MKMapViewDelegate {
    var locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        myMap.delegate = self
    }


    @IBOutlet weak var myTextView: UITextView!
    @IBOutlet weak var myMap: MKMapView!
    
    @IBAction func startTripBtn(_ sender: Any) {
    }
    @IBAction func stopTripBtn(_ sender: Any) {
    }
}

