//
//  ViewController.swift
//  NavigationController
//
//  Created by user202391 on 2/13/22.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}
    


