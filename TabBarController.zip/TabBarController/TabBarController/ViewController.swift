//
//  ViewController.swift
//  TabBarController
//
//  Created by user202391 on 2/14/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

