//
//  ViewController.swift
//  TableViewPart1Eg1
//
//  Created by user202391 on 3/17/22.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return marvelHeroes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTable.dequeueReusableCell(withIdentifier: "My Cell",for: indexPath)
        cell.textLabel?.text = marvelHeroes[indexPath.row]
        return cell
    }
    
    var marvelHeroes = ["Captain America","Hawkeye","Iron Man","Thor","Wanda","Widow","Vision",
                        "Captain America","Hawkeye","Iron Man","Thor","Wanda","Widow","Vision",
                        "Captain America","Hawkeye","Iron Man","Thor","Wanda","Widow","Vision",
                        "Captain America","Hawkeye","Iron Man","Thor","Wanda","Widow","Vision",
                        "Captain America","Hawkeye","Iron Man","Thor","Wanda","Widow","Vision"]
    override func viewDidLoad() {
        super.viewDidLoad()
        myTable.delegate = self
        myTable.dataSource = self
    }
    @IBOutlet weak var myTable: UITableView!
}

