//
//  MyTableViewCell.swift
//  TableViewPart1Eg2
//
//  Created by user202391 on 3/17/22.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBOutlet weak var marvelHeroesImage: UIImageView!
    @IBOutlet weak var marvelHeroesLabel: UILabel!
}
