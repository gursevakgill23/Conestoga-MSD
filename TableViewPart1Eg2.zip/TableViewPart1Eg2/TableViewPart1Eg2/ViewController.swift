//
//  ViewController.swift
//  TableViewPart1Eg2
//
//  Created by user202391 on 3/17/22.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var marvelHeroes = ["Calgary","Halifax","Montreal","Toronto","Vancouver","Winnipeg"]
    var marvelHeroesImages = [UIImage(named: "Calgary"),
                                UIImage(named: "Halifax"),
                                UIImage(named: "Montreal"),
                                UIImage(named: "Toronto"),
                                UIImage(named: "Vancouver"),
                                UIImage(named: "Winnipeg")]

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return marvelHeroes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTable.dequeueReusableCell(withIdentifier: "My Cell",for: indexPath)as! MyTableViewCell
        let marvelheroeslabel = self.marvelHeroes[indexPath.row]
        let marvelheroesimage = self.marvelHeroesImages[indexPath.row]
        cell.marvelHeroesLabel.text = marvelheroeslabel
        cell.marvelHeroesImage.image = marvelheroesimage
        return cell

        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        myTable.delegate = self
        myTable.dataSource = self
    }


    @IBOutlet weak var myTable: UITableView!
}

