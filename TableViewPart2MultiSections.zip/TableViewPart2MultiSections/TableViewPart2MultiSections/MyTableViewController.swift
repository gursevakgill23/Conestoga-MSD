//
//  MyTableViewController.swift
//  TableViewPart2MultiSections
//
//  Created by user202391 on 3/20/22.
//

import UIKit

class MyTableViewController: UITableViewController {
    struct Province {
    var Name : String!
    var City : [String]!
    }
    var CanadaArray = [Province]()


    override func viewDidLoad() {
        super.viewDidLoad()
        CanadaArray = [Province (Name: "Ontario", City : ["Toronto","Waterloo","Kitchener"]),
                                   Province (Name: "Quebec", City : ["Montreal","Quebec City","Laval"]),
                               Province (Name: "Albert", City : ["Calgary","Edmonton","Red Dear"]),
                               Province (Name: "Britch Columbia", City : ["Vancouver","Victoria","Richmond"]),
                               Province (Name: "Manatoba", City : ["Winipeg","Thompson","Brandon"])
                    ]

    }
    //What to display in each cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "My Cell")!
        cell.textLabel?.text = CanadaArray[indexPath.section].City[indexPath.row]
        return cell
    }



    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return CanadaArray.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return CanadaArray[section].City.count
    }
    // Display section header
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return CanadaArray[section].Name
    }

}
