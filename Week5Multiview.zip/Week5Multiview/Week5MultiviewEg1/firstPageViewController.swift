//
//  ViewController.swift
//  Week5MultiviewEg1
//
//  Created by user202391 on 2/11/22.
//

import UIKit

class firstPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func secondPageBtn(_ sender: Any) {
        let page=storyboard?.instantiateViewController(identifier: "Page2")
            as! secondPageViewController
        page.modalPresentationStyle = .fullScreen
        present(page,animated: true)
        
        
        
    }
    
}

