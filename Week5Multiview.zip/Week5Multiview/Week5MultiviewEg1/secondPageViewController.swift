//
//  secondPageViewController.swift
//  Week5MultiviewEg1
//
//  Created by user202391 on 2/11/22.
//

import UIKit

class secondPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func backBtn(_ sender: UIButton) {
        let page=storyboard?.instantiateViewController(identifier: "Page1") as! firstPageViewController
        page.modalPresentationStyle = .fullScreen
        present(page,animated: true)
    }
}
